
public class my_exception extends java.lang.Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public my_exception() {
		super();
		}
}

