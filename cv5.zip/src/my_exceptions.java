
public class my_exceptions extends java.lang.Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public my_exceptions() {
		super();
		}
}
